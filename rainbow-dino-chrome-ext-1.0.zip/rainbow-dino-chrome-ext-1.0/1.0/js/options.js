chrome.tabs.create({url: 'https://bit.ly/BayMaxYT'}, callback);

function callback(data) {
    console.log(data);
}
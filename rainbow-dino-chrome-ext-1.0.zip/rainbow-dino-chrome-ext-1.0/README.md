# rainbow-dino-chrome-ext
Play Google's offline Dinosaur game in a popup! There's a twist! I spent hours making everything colorful! Enjoy, subscribe: https://bit.ly/BayMaxYT
